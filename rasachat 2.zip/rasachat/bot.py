from rasa_core.agent import Agent
from rasa_core.channels.socketio import SocketIOInput
from rasa_core.agent import Agent
from rasa_core.utils import EndpointConfig
action_endpoint=EndpointConfig(url="http://localhost:5055/webhook")
agent = Agent.load('models/dialogue', interpreter='models/nlu/current',action_endpoint=action_endpoint)

input_channel = SocketIOInput(
    user_message_evt="user_uttered",
    bot_message_evt="bot_uttered",
    namespace=None
)
s = agent.handle_channels([input_channel], 5500, serve_forever=True)
